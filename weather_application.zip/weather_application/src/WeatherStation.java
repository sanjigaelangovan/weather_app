import java.util.ArrayList;

/**
 * A weather station measures temperature and pressure and has a list of
 * subscribed weather observers. When there is an update on the measures, the
 * weather station publishes the update to all currently-subscribed observers.
 */
public class WeatherStation {

	/*
	 * Your Task: Declare an attribute for the ***list*** of subscribed weather
	 * observers.
	 */
	double temperature;
	double pressure;
	ArrayList<WeatherObserver> ws = new ArrayList<WeatherObserver>();
	int nos;

	/**
	 * Initialize a new weather station.
	 * 
	 * @param t initial temperature measure
	 * @param p initial pressure measure
	 */
	public WeatherStation(double t, double p) {
		/* Your Task */
		this.temperature = t;
		this.pressure = p;

	}

	/**
	 * Subscribe the input weather observer o as one of the observers of the current
	 * weather station. Add the input o to the list of subscribed observers.
	 * 
	 * @param o a weather observer
	 */
	public void subscribe(WeatherObserver o) {
		/* Your Task */
		ws.add(o);
		// you need to set o.wd to be the current weather station
		o.setWeatherStation(this);
		nos++;
	}

	/**
	 * Unsubscribe the input weather observer o from the list of observers of the
	 * current weather station. Remove the input o from the list of subscribed
	 * observers. Assume that the input o is an already-subscribed observer.
	 * 
	 * @param o a weather observer
	 */
	public void unsubscribe(WeatherObserver o) {
		/* Your Task */
		ws.remove(o);
		o.setWeatherStation(null);
		nos--;

	}

	/**
	 * Publish the latest readings of weather data to all subscribed observers. That
	 * is, perform an update on each subscribed observer.
	 */
	public void publish() {
		/* Your Task */
		for (WeatherObserver x : ws) {
			x.update();
		}

	}

	/**
	 * Get the list of subscribed weather observers.
	 * 
	 * @return an array of subscribed weather observers.
	 */
	public WeatherObserver[] getObservers() {
		/* Your Task */

		WeatherObserver[] w = new WeatherObserver[nos];
		for (int i = 0; i < nos; i++) {
			w[i] = ws.get(i);
		}

		return w;

	}

	/**
	 * Get the latest temperature measure.
	 * 
	 * @return latest temperature measure
	 */
	public double getTemperature() {
		/* Your Task */
		return this.temperature;
	}

	/**
	 * Get the latest pressure measure.
	 * 
	 * @return latest pressure measure
	 */
	public double getPressure() {
		/* Your Task */
		return this.pressure;
	}

	/**
	 * Update the weather data
	 * 
	 * @param t new temperature measure
	 * @param p new pressure measure
	 */
	public void set_measurements(double t, double p) {
		/* Your Task */
		this.temperature = t;
		this.pressure = p;
	}
}
import java.util.ArrayList;

/**
 * A weather statistics app calculates the minimum, maximum, and average
 * temperature read so far from its subscribed weather station, if any.
 */
public class StatisticsApp extends WeatherObserver {

	/**
	 * Update the reading of this weather observer. Update the current temperature
	 * and the maximum, minimum, and average accordingly.
	 */
	WeatherStation Ws;
	ArrayList<Double> temperatures;
	int not;

	public void update() {
		/* Your Task */
		temperatures.add(Ws.temperature);
		not++;

	}

	/* See the method description in the parent class */
	public WeatherStation getWeatherStation() {
		/* Your Task */
		return Ws;
	}

	/* See the method description in the parent class */
	public void setWeatherStation(WeatherStation ws) {
		/* Your Task */
		this.Ws = ws;
		temperatures = new ArrayList<>();

	}

	/**
	 * Get the minimum temperature based on the readings so far.
	 * 
	 * @return minimum temperature based on the readings so far
	 */
	public double getMinTemperature() {
		/* Your Task */
		double min = temperatures.get(0);
		for (int i = 1; i < not; i++) {
			if (temperatures.get(i) < min) {
				min = temperatures.get(i);
			}
		}
		return min;
	}

	/**
	 * Get the maximum temperature based on the readings so far.
	 * 
	 * @return maximum temperature based on the readings so far
	 */
	public double getMaxTemperature() {
		/* Your Task */
		double max = temperatures.get(0);
		for (int i = 1; i < not; i++) {
			if (temperatures.get(i) > max) {
				max = temperatures.get(i);
			}
		}

		return max;
	}

	/**
	 * Get the average temperature based on the readings so far.
	 * 
	 * @return average temperature based on the readings so far
	 */
	public double getAverageTemperature() {
		/* Your Task */
		double ave = 0.0;
		for (int i = 0; i < not; i++) {
			ave += temperatures.get(i);
		}
		return ave / not;
	}
}
